
window.COMPONENTS_BASE_URL='/shared/elements/';